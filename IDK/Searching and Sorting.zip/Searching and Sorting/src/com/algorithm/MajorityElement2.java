package com.algorithm;

public class MajorityElement2 {

    // hashmap count

    // poll
}
