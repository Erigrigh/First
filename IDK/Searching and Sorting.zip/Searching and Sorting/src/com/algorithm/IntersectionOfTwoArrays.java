package com.algorithm;

public class IntersectionOfTwoArrays {
    // hashset

    //sort two pointer
}
