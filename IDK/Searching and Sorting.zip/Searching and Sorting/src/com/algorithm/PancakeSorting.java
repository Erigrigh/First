package com.algorithm;

public class PancakeSorting {
}
