package com.algorithm;

public class FindKClosestElements {
    // binary search + sliding window
    //logN + K


    //find left  border index
}
